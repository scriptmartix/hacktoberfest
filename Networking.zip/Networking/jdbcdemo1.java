import java.sql.*;
class jdbcdemo1
{

public static void main(String args[])
{
Connection con=null;
try
{

//Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");

Class.forName("com.mysql.jdbc.Driver");
con=DriverManager.getConnection("jdbc:mysql://localhost:3306/socialdemo1","root","");
System.out.println("Connection Successfully...");

con.close();

}
catch(Exception ex)
{

System.out.println(ex);
}





}
}