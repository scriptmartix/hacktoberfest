import java.sql.*;
class jdbcdemo{

public static void main(String args[]){
Connection con;
try{
Class.forName("com.mysql.jdbc.Driver");
con=DriverManager.getConnection("jdbc:mysql://localhost:3306/todo","root","");
System.out.println("Connection Successfully...");
con.close();

}catch(Exception ex){
System.out.println(ex);
}




}
}