import java.sql.*;
import java.util.*;
class jdbcinputdemo{

public static void main(String args[]){

Connection con=null;
try{
Class.forName("com.mysql.jdbc.Driver");
con=DriverManager.getConnection("jdbc:mysql://localhost:3306/todo","root","");
//System.out.println("Connection Successfully...");
Statement stat=con.createStatement();
//int id;
String tododata;

Scanner sc=new Scanner(System.in);

System.out.println("Enter Your Todo data");
tododata=sc.nextLine();
//int result=stat.executeUpdate(" create table product (proid int, proname varchar(20), proprice int) ");
int result=stat.executeUpdate(" insert into todolist values(NULL,'"+tododata+"')");
System.out.println("Inserted Successfully...");
stat.close();
con.close();
}catch(Exception ex){System.out.println(ex);}
}
}
