import java.sql.*;
import java.util.*;
class selectjdbc
{

public static void main(String args[])
{
Connection con=null;
try
{

Class.forName("com.mysql.jdbc.Driver");
con=DriverManager.getConnection("jdbc:mysql://localhost:3306/todo","root","");
System.out.println("Connection Successfully...");

Statement stat=con.createStatement();
String sql="select * from todolist";
ResultSet rs=stat.executeQuery(sql);

while(rs.next())
{
int id=rs.getInt("id");
String  tododata=rs.getString("tododata");
//int pprice=rs.getInt("proprice");

//Display Data

System.out.println("ProductId="+id);
System.out.println("ProductName="+tododata);

System.out.println("\n");


}

rs.close();

stat.close();
con.close();

}
catch(Exception ex)
{

System.out.println(ex);
}





}
}