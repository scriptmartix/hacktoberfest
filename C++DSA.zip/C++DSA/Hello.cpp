#include<bits/stdc++.h>
using namespace std;
int main(){
   cout<<"HELLO DSA"<<endl;
}